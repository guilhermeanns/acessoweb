# acessosweb
Software para monitoramento, análise e estatísticas dos logs de acessos da Internet que são armazenados pelo Squid em uma base de dados Mysql.
Projeto desenvolvido com as tecnologias: Java Web, Apache Tomcat/8.5.6, Mysql Distrib 10.1.18-MariaDB e Squid Cache 3.5.22
